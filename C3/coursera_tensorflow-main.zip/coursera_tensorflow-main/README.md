list of notebooks from the Coursera course: Introduction to TensorFlow for Artificial Intelligence,Machine Learning and Deep Learning
